define(
"dojo/cldr/nls/sv/number", //begin v1.x content
{
	"scientificFormat": "#E0",
	"currencyDecimal": ":",
	"infinity": "∞",
	"list": ";",
	"percentSign": "%",
	"minusSign": "−",
	"decimalFormat-short": "000 bn",
	"nan": "¤¤¤",
	"plusSign": "+",
	"currencyFormat": "#,##0.00 ¤",
	"perMille": "‰",
	"group": " ",
	"percentFormat": "#,##0 %",
	"decimalFormat-long": "000 biljoner",
	"decimalFormat": "#,##0.###",
	"currencyGroup": ".",
	"decimal": ",",
	"exponential": "×10^"
}
//end v1.x content
);